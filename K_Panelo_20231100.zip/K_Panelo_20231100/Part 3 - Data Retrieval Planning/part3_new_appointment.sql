"INSERT INTO `appointment_tbl`( `appoint_date_time`, `vet_id`, `room_id`, `pet_id`)";
