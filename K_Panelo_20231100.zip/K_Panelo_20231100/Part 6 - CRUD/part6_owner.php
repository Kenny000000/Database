<?php
	// include connection function getData()
	include 'conn.php';

	$customerData = " ";
	if (isset($_GET['isUpdate'])) {
		$isUpdate = $_GET['isUpdate'];
		switch ($isUpdate) {
		//---------- Delete Appointment -----------//
		case "1": 
			$id = $_GET['delete_id'];
			$sql = "DELETE FROM `appointment_tbl` WHERE `appoint_id`=?";
			$params = array($id);
			setData($sql,$params,true);
			header("Location: index.php");
			break;
			//----------Edit Customer-------------//
		case "2":
			$id = $_GET['customerID'];
			$sql = "SELECT * FROM `customer_tbl` WHERE `customer_id` = ?;";
			$params = array($id);
			$customerData = getData($sql,$params,true);
		   	break;
		   //----------Add Appointment-------------//
		case "3":
			//set up variable
			$vet = $_GET['selectVet'];
			$room = $_GET['selectRoom'];
			$pet = $_GET['selectPet'];
			$dateTime = $_GET['dateTime'];

			//Extract and Format Correctly DateTime
			$dateTime_arr = explode(" ", $dateTime); // seperate date and time
			
			$date_arr = explode("/", $dateTime_arr[0]); //seperate day, month, year

			$time = $dateTime_arr [1];

			$month = $date_arr[0];
			$day = $date_arr[1];
			$year = $date_arr[2];
			
			$dateTimeStr = $year."-".$month."-".$day."-".$time; //format correctly

			//Save to Database
			$sql = "INSERT INTO `appointment_tbl`( `appoint_date_time`, `vet_id`, `room_id`, `pet_id`)";
			$sql .= "VALUES (?,?,?,?)";
			$params = array($dateTimeStr, $vet, $room, $pet);
			setData($sql,$params,true);
			break;
		//--------------------- Edit Owner Details------------------------//
		case "4":
			$id =  $_GET['customerID'];
			$fn =  $_GET['first_name'];
			$sn =  $_GET['surname'];
			$ad1 = $_GET['address_1'];
			$ad2 = $_GET['address_2'];
			$city =   $_GET['city'];
			$eir = $_GET['eircode'];
			
			$sql = "UPDATE `customer_tbl` SET `customer_first_name`=?,`customer_surname`=?,`customer_address_1`=?,`customer_address_2`=?,`customer_city`=?,`customer_eircode`=? WHERE `customer_id`=?";
			$params = array($fn,$sn,$ad1,$ad2,$city,$eir,$id);
			setData($sql,$params,true);
			break;
		default:
		}
	}
	
	// PDO SQL
	// you need to put your SQL in a PDO format in here
	$sql = "SELECT 
	appointment_tbl.appoint_date_time,
	appointment_tbl.appoint_id,
	room_tbl.vet_name,
	vet_tbl.vet_surname,
	vet_tbl.vet_first_name,
	pet_tbl.pet_name,
	customer_tbl.customer_first_name,
	customer_tbl.customer_surname,
	pet_tbl.pet_id,
	customer_tbl.customer_id,
	room_tbl.room_id,
	vet_tbl.vet_id
	FROM 
	customer_tbl
	INNER JOIN pet_tbl
	  ON customer_tbl.customer_id = pet_tbl.customer_id
	INNER JOIN appointment_tbl
	  ON pet_tbl.pet_id = appointment_tbl.pet_id
	INNER JOIN room_tbl
	  ON appointment_tbl.room_id = room_tbl.room_id
	INNER JOIN vet_tbl
	  ON appointment_tbl.vet_id = vet_tbl.vet_id"; 
	
	// PDO Params
	// you need to include PDO variables in the array
	$params = array();
	
	// Put results into $data
	// turn on/off error messages with true/false as third value passed
	$data = getData($sql,$params,true);

	$sql = "SELECT * FROM `vet_tbl`";
	$params = array();
	$vetData = getData($sql,$params,true);

	$sql = "SELECT * FROM `room_tbl`";
	$params = array();
	$roomData = getData($sql,$params,true);
	
	$sql = "SELECT * FROM `pet_tbl`";
	$params = array();
	$petData = getData($sql,$params,true);

	
	// uncomment below lines to see results
	// var_dump($data);
	//echo ""---------------------------;
	var_dump($customerData[0]);
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>Sago Palm Vet Clinic</title>
		<link crossorigin="anonymous" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
				rel="stylesheet">
			<script crossorigin="anonymous" integrity="sha384-xBuQ/xzmlsLoJpyjoggmTEz8OWUFM0/RC5BsqQBDX2v5cMvDHcMakNTNrHIW2I5f" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
			<script crossorigin="anonymous" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
			<script crossorigin="anonymous" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
			<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.css">
			<link rel="stylesheet" href="./css/bootstrap-datetimepicker.min.css" type="text/css" media="all" />
			<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js"></script>
			<script type="text/javascript" src="./js/bootstrap-datetimepicker.min.js"></script>
			<script type="text/javascript" src="./js/demo.js"></script>
		<meta name="description"content="Source code generated using layoutit.com">
		<meta name="author" content="LayoutIt!">

		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/stylesheet.css" rel="stylesheet">

	</head>
	<body>

		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<h1>
						Sago Palm Appointments
					</h1>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="page-header">
					<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addAppointmentModal">Add Appointment</button>
				</div>
			</div>
		</div>
	<div class="row">
		<div class="col-md-12">    
			<table class="table">
				<thead>
					<tr>
						<th>Date</th>
						<th>Time</th>
						<th>Pet</th>
						<th>Customer</th>
						<th>Vet</th>
						<th>Room</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>
				</thead>
				<tbody>
					<?php
							for ($i = 0; $i < count($data); $i++) {
							?>
							<tr <?php if (fmod($i, 2) == 0) {
								echo 'class="table-active"';} ?>>
								<td>
									<?php
									$string = $data[$i]["appoint_date_time"];
									$timedate_arr = explode(" ", $string);
									echo $timedate_arr[0];
									?>
								</td>
								<td>
									<?php echo substr($timedate_arr[1], 0, -3); ?>
								</td>
								<td>
									<?php echo $data[$i]["pet_name"] ?>
								</td>
								<td>
									<?php echo $data[$i]["customer_first_name"] . " " . $data[$i]["customer_surname"]; ?>
								</td>
								<td>
									<?php echo $data[$i]["vet_first_name"] . " " . $data[$i]["vet_surname"]; ?>
								</td>
								<td>
									<?php echo $data[$i]["room_id"] ?>
								</td>
								<td>
								<a href ="?isUpdate=2&isModal=1&customerID=<?php echo $data[$i]["customer_id"]?>" type="button"class="open-EditDialog btn btn-primary" href="#editModal">Edit Owner</a>
								</td>
								<td>
								<a href ="?isUpdate=1&delete_id=<?php echo $data[$i]["appoint_id"]?>" button type="button"class="btn btn-primary">Delete</a>
								</td>
							</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

		<!---------------------------- Start add Appointment Modal------------------------------------->
		<div class="row">
			<div class="col-md-12">
				<div class="modal fade" id="addAppointmentModal" tabindex="-1" role="dialog" aria-labelledby="addAppointmentLabel" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="addAppointmentLabel">Make Appointment</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
								</button>
							</div>
		<!---------------------- End add Appointment Modal-------------------------------------------->
					
							<!---------------------------------------- Start Form----------------------------------------->
							<form action="/sago_palm/index.php" method="get">
								<div class="modal-body">
									<input type="hidden" id="isUpdate" name="isUpdate" value="3">
									<!-----------------------------------Select a Vet-------------------------->
									<div class="form-group">	
										<label for="selectVet">Select a vet</label>
										<select class="form-control" id="selectVet" name="selectVet">
												
											<?php
												for ($i=0; $i<count($vetData); $i++) {
												echo '<option value="'.$vetData[$i]["vet_id"].'">'.$vetData[$i]["vet_first_name"].' '.$vetData[$i]["vet_surname"].'</option>';
												}
											?>				
										</select>
									</div>

									<!-----------------------------------Select Room-------------------------->	

									<div class="form-group">

										<input type="hidden" id="isUpdate" name="isUpdate" value="3">
										<label for="selectRoom">Select a Room</label>
										<select class="form-control" id="selectRoom" name="selectRoom">
												
											<?php
												for ($i=0; $i<count($roomData); $i++) {
												echo '<option value="'.$roomData[$i]["room_id"].'">'.$roomData[$i]["room_id"].'</option>';
												}
											?>				
										</select>
									</div>

									<!-----------------------------------Select Pet-------------------------->	
									<div class="form-group">

										<label for="selectPet">Select a Pet </label>
										<select multiple class="form-control" id="selectPet" name="selectPet" value="1">
												<?php
											for ($i=0; $i<count($petData); $i++) {
															echo '<option value="'.$petData[$i]["pet_id"].'">'.$petData[$i]["pet_name"].'</option>';
														}
											?>
										</select>

									</div>

									<!-----------------------------------Select Date & Time-------------------------->	
									<div class="form-group">
										<label for="appointmentDateTime">Select Date & Time</label>
										<div class="input-group date" id="id_1">
											<input type="text" value="02/29/2024 12:00" class="form-control" id="dateTime" name="dateTime"required/>
											<div class="input-group-addon input-group-append">
												<div class="input-group-text">
													<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
												</div>
											</div>
										</div>
									</div>

									<div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
										<button  class="btn btn-primary" type="submit" value="Submit" role="form">Book Appointment</button>
									</div>
								</div>
							</form>
							<!----------------------------- End Form------------------------------------------------>
						</div>	
					</div>				
				</div>
			</div>
		</div>
		<!-------------------------------- Start of Edit Modal------------------------------------------->
		<div class="row">
			<div class="col-md-12">
				<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLabel">Edit Appointment</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<!------ Start Edit Owner ------>
								<form>
									<div class="form-group row">
										<input type="hidden" id="isUpdate" name="isUpdate" value="4"> 
										<input type="hidden" id="customerID" name="customerID" value="<?php echo $customerData[0]["customer_id"]?>"> 
										<label for="firstname" class="col-4 col-form-label">First Name</label> 
										<div class="col-8">
											<input id="first_name" name="first_name" type="text" class="form-control" value="<?php echo $customerData[0]["customer_first_name"]?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="surname" class="col-4 col-form-label">Surname</label> 
										<div class="col-8">
											<input id="surname" name="surname" type="text" class="form-control" value="<?php echo $customerData[0]["customer_surname"]?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="address_1" class="col-4 col-form-label">Address 1</label> 
										<div class="col-8">
											<input id="address_1" name="address_1" type="text" class="form-control" value="<?php echo $customerData[0]["customer_address_1"]?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="address_2" class="col-4 col-form-label">Address 2</label> 
										<div class="col-8">
											<input id="address_2" name="address_2" type="text" class="form-control" value="<?php echo $customerData[0]["customer_address_2"]?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="city" class="col-4 col-form-label">City</label> 
										<div class="col-8">
											<input id="address_3" name="city" type="text" class="form-control" value="<?php echo $customerData[0]["customer_city"]?>">
										</div>
									</div>
									<div class="form-group row">
										<label for="eircode" class="col-4 col-form-label">Eircode</label> 
										<div class="col-8">
											<input id="eircode" name="eircode" type="text" class="form-control" value="<?php echo $customerData[0]["customer_eircode"]?>">
										</div>
									</div> 
									<div class="form-group row">
										<div class="offset-4 col-8">
											<button name="submit" type="submit" class="btn btn-primary">Submit</button>
										</div>
									</div>
								</form>
								<!------ End Edit Owner ---->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-------------------------------- End of Edit Modal------------------------------------------->
	
		

		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/scripts.js"></script>
		<script>
			$(window).on('load', function() {
				let isModal = "0";
				const queryString = window.location.search;
				const urlParams = new URLSearchParams(queryString);
				isModal = urlParams.get('isModal');
				if(isModal){
				$('#editModal').modal('show');
			}
			});
			$(document).on("click", ".open-EditDialog", function () {
				var myEditId = $(this).data('id');
				$(".modal-body #editId").val( myEditId );
			});
		</script>
	</body>
</html>
