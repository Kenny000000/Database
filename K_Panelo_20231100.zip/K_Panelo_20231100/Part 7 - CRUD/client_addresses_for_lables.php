<?php
include 'conn.php';
$sql = "SELECT * FROM `client_addresses_view`;";
$params = array();
$data = getData($sql,$params,true);
// var_dump($customerData[0]);
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Bootstrap 4, from LayoutIt!</title>

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

  </head>
  <body>

  <div class="container-fluid">
        <div class="row">
        <table style="width: 100%;" border="1" cellpadding="5">
                    <tr>
                      <td><b>Customer First Name</b></td>
                      <td><b>Customer Surname</b></td>
                      <td><b>Address 1</b></td>
                      <td><b>Address 2</b></td>
                      <td><b>City</b></td>
                      <td><b>Eircode</b></td>
                    </tr>
                    <tbody>
                        <?php for($i = 0; $i < count($data); $i++){?>
                          <tr>
                            <td><?php echo $data[$i]["customer_first_name"]?></td>
                            <td><?php echo $data[$i]["customer_surname"]?></td>
                            <td><?php echo $data[$i]["customer_address_1"]?></td>
                            <td><?php echo $data[$i]["customer_address_2"]?></td>
                            <td><?php echo $data[$i]["customer_city"]?></td>
                            <td><?php echo $data[$i]["customer_eircode"]?></td>
                          </tr>
                       <?php }?>
                   </tbody>
              </table>
        </div>
     </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>