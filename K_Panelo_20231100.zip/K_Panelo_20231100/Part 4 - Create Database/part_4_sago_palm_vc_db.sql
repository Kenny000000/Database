-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2024 at 03:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sago_palm_vc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_tbl`
--

CREATE TABLE `appointment_tbl` (
  `appoint_id` int(11) NOT NULL,
  `appoint_date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `vet_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment_tbl`
--

INSERT INTO `appointment_tbl` (`appoint_id`, `appoint_date_time`, `vet_id`, `room_id`, `pet_id`) VALUES
(1, '2024-01-23 14:00:00', 1, 1, 1),
(2, '2024-01-23 14:30:00', 1, 1, 2),
(3, '2024-01-23 15:00:00', 1, 1, 3),
(4, '2024-01-23 15:30:00', 1, 1, 4),
(5, '2024-01-23 16:00:00', 1, 1, 5),
(6, '2024-01-23 16:30:00', 1, 1, 6),
(7, '2024-01-23 17:00:00', 1, 1, 7),
(8, '2024-01-23 14:00:00', 2, 2, 8),
(9, '2024-01-23 14:30:00', 2, 2, 9),
(10, '2024-01-23 15:00:00', 2, 2, 10),
(11, '2024-01-23 15:30:00', 2, 2, 11),
(12, '2024-01-23 16:00:00', 2, 2, 12),
(13, '2024-01-23 16:30:00', 2, 2, 13),
(14, '2024-01-23 17:00:00', 2, 2, 14),
(15, '2024-01-23 14:00:00', 3, 3, 15),
(16, '2024-01-23 14:30:00', 3, 3, 16),
(17, '2024-01-23 15:00:00', 3, 3, 17),
(18, '2024-01-23 15:30:00', 3, 3, 18),
(19, '2024-01-23 16:00:00', 3, 3, 19),
(20, '2024-01-23 16:30:00', 3, 3, 20),
(21, '2024-01-23 17:00:00', 3, 3, 21);

-- --------------------------------------------------------

--
-- Table structure for table `customer_tbl`
--

CREATE TABLE `customer_tbl` (
  `customer_id` int(11) NOT NULL,
  `customer_first_name` varchar(16) NOT NULL,
  `customer_surname` varchar(16) NOT NULL,
  `customer_address_1` varchar(20) NOT NULL,
  `customer_address_2` varchar(20) NOT NULL,
  `customer_city` varchar(12) NOT NULL,
  `customer_eircode` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_tbl`
--

INSERT INTO `customer_tbl` (`customer_id`, `customer_first_name`, `customer_surname`, `customer_address_1`, `customer_address_2`, `customer_city`, `customer_eircode`) VALUES
(1, 'Matthew', 'Cawley', '94 Richmond Road', 'Covent Garden', 'London', 'SW72 6B'),
(2, 'Emmanuel', 'Fulfilled', '39 Park Road', 'Covent Garden', 'London', 'SW45 1C'),
(3, 'Youcef', 'Hezam', '33 Chester Road', 'Covent Garden', 'London', 'NW68 3X'),
(4, 'Rahma', 'Ismail', '66 School Lane', 'Windsor Castle', 'London', 'SW34 7L'),
(5, 'Lukasz', 'Kiraga', '508 Grange Road', 'Covent Garden', 'London', 'NW90 5G'),
(6, 'Jamie', 'Matthews', '977 Park Avenue', 'Clapham', 'London', 'EC58 3G'),
(7, 'Kieran', 'Panelo', '1 The Crescent', 'Clapham', 'London', 'SE75 8O'),
(8, 'Patrisia', 'Pascal', '61 Springfield Road', 'Fullham', 'London', 'SE79 3P'),
(9, 'Will', 'Quinn Branagan', '72 Grove Road', 'Fullham', 'London', 'W51 2ZX'),
(10, 'Hugh', ' Ruane', '401 South Street', 'Fullham', 'London', 'SW40 6S'),
(11, 'Cain', 'Sheridan', '68 Broadway', 'Fullham', 'London', 'E53 1YC'),
(12, 'Jan', 'Uy', '63 Church Road', 'Fullham', 'London', 'W51 3CK'),
(13, 'Youcuf', 'Hezam', '12 Windsor Road', 'Covent Garden', 'London', 'SW53 2G');

-- --------------------------------------------------------

--
-- Table structure for table `pet_tbl`
--

CREATE TABLE `pet_tbl` (
  `pet_id` int(10) NOT NULL,
  `pet_name` varchar(20) NOT NULL,
  `allergies` varchar(20) NOT NULL,
  `species` varchar(20) NOT NULL,
  `neutered` tinyint(1) NOT NULL COMMENT '1=Neutered 0=False',
  `age` tinyint(4) NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pet_tbl`
--

INSERT INTO `pet_tbl` (`pet_id`, `pet_name`, `allergies`, `species`, `neutered`, `age`, `customer_id`) VALUES
(1, 'Indiana Bones', 'bones', 'labrador', 0, 5, 2),
(2, 'Kanye Westie', 'none', 'pitbull', 1, 2, 10),
(3, 'Jude Paw', 'chocolate', 'boxer', 0, 11, 4),
(4, 'Dwain', 'none', 'Labrador retriever', 1, 4, 5),
(5, 'Mutt Damon', 'rocks', 'Golden retriever', 0, 2, 5),
(6, 'Bark Wahlberg', 'none', 'German shepherd', 1, 6, 3),
(7, 'Bark E. Bark', 'grass', 'Poodle', 1, 9, 4),
(8, 'Benedict Cumberbark', 'none', 'Shih Tzu', 0, 3, 5),
(9, 'Jon Bone Jovi', 'none', 'Rottweiler', 1, 6, 7),
(10, 'Sarah Jessica Barker', 'none', 'Beagle', 1, 3, 6),
(11, 'Woofie Goldberg', 'plastic', 'Daschund', 0, 21, 7),
(12, 'Catrick Swayze', 'none', 'German shorthaired p', 1, 5, 8),
(13, 'Meowly Cyrus', 'none', 'Pembroke Welsh corgi', 1, 2, 9),
(14, 'Snarls Barkley', 'biscuits', 'Australian shepherd', 0, 3, 10),
(15, 'The Notorious D.O.G.', 'none', 'Yorkshire terrier', 0, 6, 11),
(16, 'Winnie the Pooch', 'none', 'Cavalier King Charle', 0, 7, 12),
(17, 'Bilbo Waggins', 'none', 'Doberman pinscher', 1, 4, 13),
(18, 'Mary Puppins', 'none', 'Boxers', 0, 9, 4),
(19, 'Kitty Pawpins', 'none', 'Miniature schnauzer', 0, 9, 7),
(20, 'Sherlock Bones', 'none', 'Cane corso', 1, 12, 11),
(21, 'Andy Warhowl', 'bees', 'pug', 1, 24, 7);

-- --------------------------------------------------------

--
-- Table structure for table `room_tbl`
--

CREATE TABLE `room_tbl` (
  `room_id` int(11) NOT NULL,
  `vet_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_tbl`
--

INSERT INTO `room_tbl` (`room_id`, `vet_name`) VALUES
(1, 'Evans'),
(2, 'Holland'),
(3, 'Slate');

-- --------------------------------------------------------

--
-- Table structure for table `vet_tbl`
--

CREATE TABLE `vet_tbl` (
  `vet_id` int(11) NOT NULL,
  `vet_first_name` varchar(20) NOT NULL,
  `vet_surname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vet_tbl`
--

INSERT INTO `vet_tbl` (`vet_id`, `vet_first_name`, `vet_surname`) VALUES
(1, 'Louis', 'Capaldi'),
(2, 'Micheal', 'Jackson'),
(3, 'Bruno', 'Mars');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  ADD PRIMARY KEY (`appoint_id`),
  ADD UNIQUE KEY `id` (`appoint_id`),
  ADD KEY `vet_id` (`vet_id`,`room_id`,`pet_id`),
  ADD KEY `pet_id` (`pet_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `customer_tbl`
--
ALTER TABLE `customer_tbl`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `id` (`customer_id`);

--
-- Indexes for table `pet_tbl`
--
ALTER TABLE `pet_tbl`
  ADD PRIMARY KEY (`pet_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `id` (`pet_id`);

--
-- Indexes for table `room_tbl`
--
ALTER TABLE `room_tbl`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `id` (`room_id`);

--
-- Indexes for table `vet_tbl`
--
ALTER TABLE `vet_tbl`
  ADD PRIMARY KEY (`vet_id`),
  ADD KEY `id` (`vet_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  MODIFY `appoint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `customer_tbl`
--
ALTER TABLE `customer_tbl`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `pet_tbl`
--
ALTER TABLE `pet_tbl`
  MODIFY `pet_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `room_tbl`
--
ALTER TABLE `room_tbl`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vet_tbl`
--
ALTER TABLE `vet_tbl`
  MODIFY `vet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment_tbl`
--
ALTER TABLE `appointment_tbl`
  ADD CONSTRAINT `appointment_tbl_ibfk_4` FOREIGN KEY (`pet_id`) REFERENCES `pet_tbl` (`pet_id`),
  ADD CONSTRAINT `appointment_tbl_ibfk_5` FOREIGN KEY (`vet_id`) REFERENCES `vet_tbl` (`vet_id`),
  ADD CONSTRAINT `appointment_tbl_ibfk_6` FOREIGN KEY (`room_id`) REFERENCES `room_tbl` (`room_id`);

--
-- Constraints for table `pet_tbl`
--
ALTER TABLE `pet_tbl`
  ADD CONSTRAINT `pet_tbl_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_tbl` (`customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
